var path=require("path");
var webpack = require('webpack');
var HtmlWebpackPlugin = require('html-webpack-plugin');
var OpenBrowserPlugin = require('open-browser-webpack-plugin');

module.exports = {
    devtool: 'eval-source-map',

    entry: path.join(__dirname, "app", "main.js"),
    output: {
        path: path.join(__dirname, "public"),
        filename: "bundle.js"
    },

    module: {
        loaders: [
            {
                test: /\.json$/,
                loader: "json-loader"
            },
            {
                test: /\.js$/,
                exclude: /node_modules/,
                loader: 'babel-loader',
                query: {
                    presets: ['es2015', 'react']
                }
            },
            {
                test: /\.css$/,
                loader: 'style-loader!css-loader?modules'
            }
        ]
    },


    plugins: [
        new webpack.BannerPlugin("Copyright By TWL Matthew."),
        new HtmlWebpackPlugin({
            template:path.join(__dirname,"app","index.tmpl.html")
        }),
        new webpack.HotModuleReplacementPlugin(),
        new OpenBrowserPlugin({url: 'http://localhost:8080/'})
    ],

    devServer: {
        contentBase: path.join(__dirname, "public"),//本地服务器所加载的页面所在的目录
        inline: true,
        hot:true,
        historyApiFallback: true
    }
};